import javax.swing.*;
/**
* MP3 extends Gadget
* MP3 class field
*/
public class MP3 extends Gadget
{
    
    private int availableMemory;
    /**
     * Constructor to initialize all fields for class MP3
     * pass model, price, weight, size to super class constructor
     * initialize available memory
     */
    public MP3(String model, double price, int weight, String size, int availableMemory)
    {
        
        super(model, price, weight, size);
        this.availableMemory = availableMemory;
    }

    /**
     * get method to return available memory
     */
    public int getAvailableMemory()
    {
        
        return availableMemory;
    }
    
    /**
     * void method for downloading music, and check
     * if there's enough memory deduce from availableMemory, and
     * if there's is not enough memory then print a message: "Not enough memory to download music"
     */
    public void downloadMusic(int memorySize){
    if(availableMemory >= memorySize){
    availableMemory-=memorySize;
    JOptionPane.showMessageDialog(GadgetShop.frame,
    "You've successfuly downloaded music. Remaining memory left: "
    + getAvailableMemory());} else {
    JOptionPane.showMessageDialog(GadgetShop.frame, "Not enough memory to download music"); }}
    
    /**
     * void method to delete music to free up space, and
     * if there's a space then add to available memory,
     * if not, then print a message: "Invalid memory value"
     */
    public void deleteMusic(int memorySize){
    if(memorySize>0){
    availableMemory+=memorySize;} else {
    System.out.println("ERROR: Invalid memory value"); }}
    
    /**
     * void method to display MP3 details and available memory
     */
    public void display(){
    super.display();
    System.out.println("Available Memory: " + availableMemory); }
}
