import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GadgetShop implements ActionListener  {
    ArrayList <Mobile> mobiles = new ArrayList <>();
    ArrayList <MP3> mp3s = new ArrayList <>();
    
    private GadgetShop shop;
    private JLabel statusLabel;
    private Mobile mobile;
    private JTextField modelField;
    private JTextField priceField;
    private JTextField weightField;
    private JTextField sizeField;
    private JTextField creditField;
    private JTextField memoryField;
    private JTextField phoneNoField;
    private JTextField durationField;
    private JTextField downloadField;
    private JTextField displayNumberField;
    
    private JButton mobileButton;
    private JButton mp3Button;
    private JButton clearButton;
    private JButton displayButton;
    private JButton callButton;
    private JButton downloadButton;
    
    public static JFrame frame;
    
    public GadgetShop() 
    {
        
        makeFrame();
    }
    

    /**
     * Create the Swing frame and its content.
     */
    public void makeFrame()
    {
        
        frame = new JFrame("GadgetShop");
        frame.setLayout(new GridLayout(7, 4));
        
        
        Container contentPane = frame.getContentPane();
        
        JLabel modelLabel = new JLabel("Model:");
        modelField = new JTextField();
        
        JLabel priceLabel = new JLabel("Price:");
        priceField = new JTextField();
        
        JLabel weightLabel = new JLabel("Weight:");
        weightField = new JTextField();
        
        JLabel sizeLabel = new JLabel("Size:");
        sizeField = new JTextField();
        
        JLabel creditLabel = new JLabel("Credit:");
        creditField = new JTextField();
        
        JLabel memoryLabel = new JLabel("Memory:");
        memoryField = new JTextField();
        
         JLabel phoneNoLabel = new JLabel("Phone No:");
        phoneNoField = new JTextField();
        
        JLabel durationLabel = new JLabel("Duration:");
        durationField = new JTextField();
        
        JLabel downloadLabel = new JLabel("Download:");
        downloadField = new JTextField();
        
        JLabel displayNumberLabel = new JLabel("Display Number:");
        displayNumberField = new JTextField();
        
        mobileButton = new JButton("Add Mobile");
        mobileButton.addActionListener(this);
        mp3Button = new JButton("Add MP3");
        mp3Button.addActionListener(this);
        clearButton = new JButton("Clear");
        clearButton.addActionListener(this);
        displayButton = new JButton("Display All");
        displayButton.addActionListener(this);
        callButton = new JButton("Make A Call");
        callButton.addActionListener(this);
        downloadButton = new JButton("Download Music");
        downloadButton.addActionListener(this);
        
        
        
        contentPane.add(modelLabel);
        contentPane.add(priceLabel);
        contentPane.add(weightLabel);
        contentPane.add(sizeLabel);
        contentPane.add(modelField);
        contentPane.add(priceField);
        contentPane.add(weightField);
        contentPane.add(sizeField);
        contentPane.add(creditLabel);
        contentPane.add(memoryLabel);
        contentPane.add(mobileButton);
        contentPane.add(mp3Button);
        contentPane.add(creditField);
        contentPane.add(memoryField);
        contentPane.add(clearButton);
        contentPane.add(displayButton);
        contentPane.add(phoneNoLabel);
        contentPane.add(durationLabel);
        contentPane.add(downloadLabel);
        contentPane.add(displayNumberLabel);
        contentPane.add(phoneNoField);
        contentPane.add(durationField);
        contentPane.add(downloadField);
        contentPane.add(displayNumberField);
        contentPane.add(callButton);
        contentPane.add(downloadButton);
        
        
        frame.pack();
        frame.setVisible(true);
        
        
        }
        
     private void clear()
    {
        modelField.setText("");
        priceField.setText("");
        weightField.setText("");
        sizeField.setText("");
        creditField.setText("");
        memoryField.setText("");
        phoneNoField.setText("");
        durationField.setText("");
        downloadField.setText("");
        displayNumberField.setText("");
        
    }
    
     public void actionPerformed(ActionEvent event)
    {
        String someAction = event.getActionCommand();
        if(someAction == "Add Mobile")
        {
            mobiles.add(new Mobile(modelField.getText(), 
            Double.parseDouble(priceField.getText()), 
            Integer.parseInt(weightField.getText()), sizeField.getText(), 
            Integer.parseInt(creditField.getText())));
            JOptionPane.showMessageDialog(frame, "You've successfuly added a mobile phone.");
            
    
        } 
        
        else if (someAction == "Add MP3")
        {
            mp3s.add(new MP3(modelField.getText(), 
            Double.parseDouble(priceField.getText()),
            Integer.parseInt(weightField.getText()), sizeField.getText(), 
            Integer.parseInt(memoryField.getText())));
            JOptionPane.showMessageDialog(frame, "You've successfuly added a MP3.");
            
        }
      
        else if (someAction == "Make A Call") 
        {

            try
            {
            Mobile phone = mobiles.get(Integer.parseInt(displayNumberField.getText()));
            phone.makeCall(phoneNoField.getText(), 
            Integer.parseInt(durationField.getText()));
            
           
            }
            catch(NumberFormatException e)
            {
            JOptionPane.showMessageDialog(frame, "Please enter value in a correct format.");
            }
            catch(IndexOutOfBoundsException e)
            {
            JOptionPane.showMessageDialog(frame, "Mobile phone not found");
            }
            
        }
        else if (someAction == "Download Music")
        {
            try
            {
            MP3 music = mp3s.get(Integer.parseInt(displayNumberField.getText()));
            music.downloadMusic(Integer.parseInt(downloadField.getText()));
            
            }
            catch(NumberFormatException e)
            {
             JOptionPane.showMessageDialog(frame, "Please, enter value in a correct format!");
            }
            catch(IndexOutOfBoundsException e)
            {
            JOptionPane.showMessageDialog(frame, "MP3 player not found");
            }
            
        }
        else if (someAction == "Display All")
        {
        
            for(Mobile mobile: mobiles) 
            {
                mobile.display();
            }
            
            for(MP3 mp3: mp3s)
            {
                mp3.display();
            }
            
        }
        else if (someAction == "Clear") 
        {
            clear();
        }
    
    }
}
  

   


