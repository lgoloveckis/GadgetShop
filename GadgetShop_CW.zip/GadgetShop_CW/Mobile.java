import javax.swing.*;
/**
 * Mobile extends Gadget
 * Mobile class field
 */
public class Mobile extends Gadget
{
    
    private int callCredit;

    /**
     * Constructor to initialize all fields for class Mobile 
     * pass model, prize, weight, size to super class constructor
     * initialize call credit
     */
    public Mobile(String model, double price, int weight, String size, int callCredit)
    {
        
        super(model,price,weight,size);
        this.callCredit = callCredit;
    }

    /**
     * get method to return the value for call credit
     */
    public int getCallCredit()
    {
        
        return callCredit;
    }
    
    /**
     * void method to add credits to the call credit value
     * validating credit, if value is valid then add credit
     * if value is invalid then displaying a message: Please enter a positive amount
     */
    public void addCredit(int credits)
    {
    if(credits>0){
    callCredit+=credits;} else {
    System.out.println("Please enter a positive value"); }}
    
    /**
     * void method to make a call if there's enough credit and deducting call credit
     * or display a message "Insufficient credits to make this call" if there's no enough credit
     */
    public void makeCall(String phone, int duration)
    {
    if(callCredit>=duration){
    callCredit-=duration;    
    JOptionPane.showMessageDialog(GadgetShop.frame,"You've made a call to: "
    + phone + " \nRemaining calling minutes left: " + getCallCredit());
    } else {
    JOptionPane.showMessageDialog(GadgetShop.frame,"ERROR: Insufficient credits to make this call"); }}
    
    /**
     * void method of displaying Mobile details and available call credit
     */
    public void display(){
    super.display();
    System.out.println("Call Credit:" + callCredit + " minutes"); }
}
