
/**
 * Gadget class fields
 */
public class Gadget
{
    
    private String model;
    private double price; 
    private int weight; 
    private String size; 

    /**
     * Constructor to initialize all fields for class Gadget
     */
    public Gadget(String model, double price, int weight, String size)
    {
        this.model = model;
        this.price = price;
        this.weight = weight;
        this.size = size;
    }

    /**
     * get method to return the value for model
     */
    public String getModel()
    {
        
        return model;
    }
    
    /**
     * get method to return the value for price 
     */
    public double getPrice()
    {
        return price;
    }
    
    /**
     * get method to return the value for weight
     */
    public int getWeight()
    {
        return weight;
    }
    
    /**
     * get method to return the value for size
     */
    public String getSize()
    {
        return size;
    }
    
    /**
     * to print/display the gadget details
     */
    public void display()
    {
        System.out.println("Model: " + model);
        System.out.println("Price: £" + price);
        System.out.println("Weight: " + weight + " grams");
        System.out.println("Size:" + size);
        }
}
